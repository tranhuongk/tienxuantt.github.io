<?php

use Magento\Lib as MA;

require_once 'Magento/Lib/Student.php';

MA\showHello('ABC');

echo MA\MYNAME;