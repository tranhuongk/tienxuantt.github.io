<?php
namespace Foo\Bar\subnamespace;

const FOO = 1;
function foo() {echo '<h3 style="color:red;font-weight:bold">' . __FILE__ . '</h3>';}
class foo
{
    static function staticmethod() {}
}
?>