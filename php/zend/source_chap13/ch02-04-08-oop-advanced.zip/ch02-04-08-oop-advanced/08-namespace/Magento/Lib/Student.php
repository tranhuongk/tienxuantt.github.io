<?php

namespace Magento\Lib;

// CLASS

class Student {
	
	public $birthday	= '23/02/1989';
}

// FUNCTION

function showHello($name){
	echo "Hello {$name}!";
}

// CONSTANT

const MYNAME	= 'Peter Brown';