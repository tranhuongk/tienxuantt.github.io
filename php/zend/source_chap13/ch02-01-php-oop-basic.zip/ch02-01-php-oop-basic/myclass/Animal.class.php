<?php

class Animal {

}